# Schwab API Auto Token Refresh System

## 🎯 What This Does

Your old system required manual re-authentication every 30 minutes. This new system:
- ✅ **Automatically refreshes** tokens when they expire
- ✅ **Runs multiple times** per day without manual intervention
- ✅ **Lasts 7 days** before needing re-authentication (vs 30 minutes)
- ✅ **Works seamlessly** with your existing scripts

---

## 📦 Files Included

1. **schwab_auth_with_refresh.py** - Main authentication system with auto-refresh
2. **token_helper.py** - Simple helper for your scripts to get tokens
3. **EXAMPLE_token_usage.py** - Shows how to update your scripts
4. **tokens.json** - Auto-generated file storing your tokens (replaces tokens.txt)

---

## 🚀 Setup Instructions

### Step 1: Initial Authentication

Run this **ONE TIME** to get your initial tokens:

```bash
python schwab_auth_with_refresh.py
```

This will:
1. Open your browser
2. Ask you to log in to Schwab
3. Save tokens to `tokens.json`
4. Tokens are valid for **7 days**

### Step 2: Update Your Existing Scripts

You need to update `fetch_options_chain.py` to use the new token system.

**Find this code in your script:**
```python
# OLD WAY - Remove this
with open("tokens.txt", "r") as f:
    lines = f.readlines()
    access_token = lines[0].split("=")[1].strip()
```

**Replace with this:**
```python
# NEW WAY - Add this
from token_helper import get_token

access_token = get_token()
if not access_token:
    print("❌ No valid token. Run: python schwab_auth_with_refresh.py")
    exit()
```

That's it! The rest of your script stays the same.

---

## 💡 How Auto-Refresh Works

### Scenario 1: Token Still Valid
```
You run fetch_options_chain.py
  ↓
token_helper checks: "Token expires at 10:30 AM, it's 10:00 AM"
  ↓
Returns existing token (no refresh needed)
  ↓
Your script runs normally
```

### Scenario 2: Token Expired
```
You run fetch_options_chain.py
  ↓
token_helper checks: "Token expired at 10:00 AM, it's 10:35 AM"
  ↓
Automatically uses refresh token to get new access token
  ↓
Returns fresh token
  ↓
Your script runs normally (you never knew it refreshed!)
```

### Scenario 3: Refresh Token Expired (After 7 Days)
```
You run fetch_options_chain.py
  ↓
token_helper checks: "Refresh token expired"
  ↓
Returns None
  ↓
Your script tells you to run: python schwab_auth_with_refresh.py
```

---

## 🔧 Daily Workflow (Phase 4 Testing)

### Morning Routine (9:00 AM):
```bash
python fetch_options_chain.py
python calculate_gex.py
```

**That's it!** Tokens refresh automatically if needed.

### Running Multiple Times:
```bash
# 9:00 AM
python fetch_options_chain.py   # Uses token

# 10:00 AM  
python fetch_options_chain.py   # Auto-refreshes token, runs fine

# 11:00 AM
python fetch_options_chain.py   # Uses refreshed token

# No manual intervention needed!
```

---

## 📋 Token Lifecycle

| Time | Token Status | What Happens |
|------|-------------|--------------|
| **0 min** | Fresh token from authentication | Full 30 minutes available |
| **28 min** | Still valid (2 min buffer) | Uses existing token |
| **30 min** | Expired | Auto-refresh with refresh token |
| **30+ min** | New access token | Full 30 minutes available again |
| **7 days** | Refresh token expires | Need to re-authenticate (run script) |

---

## ✅ Testing the System

### Test 1: Check Current Status
```bash
python token_helper.py
```
This shows if your tokens are valid.

### Test 2: Verify Auto-Refresh Works
1. Authenticate once: `python schwab_auth_with_refresh.py`
2. Wait 35 minutes (or change token_expiry in tokens.json to test)
3. Run: `python token_helper.py`
4. Should say "refreshing token..." and work!

---

## 🐛 Troubleshooting

### Problem: "No valid token available"
**Solution:** Run `python schwab_auth_with_refresh.py` to authenticate

### Problem: "Token refresh failed"
**Solution:** Refresh token expired (after 7 days). Run full authentication again.

### Problem: Old tokens.txt file still exists
**Solution:** The new system uses `tokens.json`. You can delete `tokens.txt` (keep as backup if you want).

---

## 📝 Migration Checklist

- [ ] Copy these files to your project folder: `G:\My Drive\Trading\GEX_API\`
  - schwab_auth_with_refresh.py
  - token_helper.py
  - EXAMPLE_token_usage.py
  
- [ ] Run initial authentication: `python schwab_auth_with_refresh.py`

- [ ] Update `fetch_options_chain.py` to use `get_token()` instead of reading tokens.txt

- [ ] Test the updated script: `python fetch_options_chain.py`

- [ ] Verify it works multiple times in 30+ minutes

- [ ] Ready for Phase 4 testing! 🎉

---

## 🎓 Key Benefits for Phase 4 & Beyond

**Phase 4 (Parallel Testing):**
- Run script at 9:00 AM, 9:30 AM, 10:00 AM without re-auth
- Compare API vs GEXStream multiple times per day
- No interruptions during testing

**Phase 5 (Dynamic Updates):**
- Poll every 10-15 minutes automatically
- Tokens refresh in the background
- System can run all day without manual intervention

**Phase 6 (Production):**
- Scheduled morning execution (8:45 AM) just works
- Auto-refresh handles everything
- Only need to re-authenticate once per week

---

## 📞 Questions?

**"Do I need to change calculate_gex.py?"**
- No, it doesn't use tokens. Only fetch_options_chain.py needs updating.

**"What if I forget to re-authenticate after 7 days?"**
- Script will tell you. Just run: `python schwab_auth_with_refresh.py`

**"Can I still use my old schwab_auth.py?"**
- Yes, but you'll have to manually re-run it every 30 minutes. The new system is much better.

**"Is this ready for Phase 4?"**
- Yes! This solves the token expiration issue so you can test properly.
